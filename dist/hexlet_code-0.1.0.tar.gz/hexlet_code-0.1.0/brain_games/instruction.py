INSTRUCTION_EVEN = 'Answer "yes" if the number is even, otherwise answer "no".'
