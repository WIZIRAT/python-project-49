### Hexlet tests and linter status:
[![Actions Status](https://github.com/WIZIRAT/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/WIZIRAT/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/129b114f4a64de41ae20/maintainability)](https://codeclimate.com/github/WIZIRAT/python-project-49/maintainability)
