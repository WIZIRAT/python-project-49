INSTRUCTION_EVEN = 'Answer "yes" if the number is even, otherwise answer "no".'
INSTRUCTION_CALC = 'What is the result of the expression?'